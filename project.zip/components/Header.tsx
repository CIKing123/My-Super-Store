import { ShoppingCart, Search, User } from 'lucide-react';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  cartItemCount: number;
}

export function Header({ currentPage, onNavigate, cartItemCount }: HeaderProps) {
  const navItems = ['Home', 'Shop', 'Collections', 'About'];

  return (
    <header className="bg-[#0A0A0A] sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <button 
            onClick={() => onNavigate('home')}
            className="tracking-widest cursor-pointer border-none bg-transparent bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            LUXE
          </button>

          {/* Navigation */}
          <nav className="flex gap-12">
            {navItems.map((item) => (
              <button
                key={item}
                onClick={() => onNavigate(item.toLowerCase())}
                className={`
                  transition-colors cursor-pointer border-none bg-transparent
                  ${currentPage === item.toLowerCase() 
                    ? 'bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent' 
                    : 'text-white hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent'
                  }
                `}
              >
                {item}
              </button>
            ))}
          </nav>

          {/* Icons */}
          <div className="flex items-center gap-6">
            <button className="text-white hover:text-[#FFE55C] transition-colors cursor-pointer border-none bg-transparent p-0">
              <Search size={24} strokeWidth={2.5} />
            </button>
            <button className="text-white hover:text-[#FFE55C] transition-colors cursor-pointer border-none bg-transparent p-0">
              <User size={24} strokeWidth={2.5} />
            </button>
            <button 
              onClick={() => onNavigate('cart')}
              className="relative cursor-pointer border-none bg-transparent p-0"
            >
              <ShoppingCart size={24} strokeWidth={2.5} className="text-[#D4AF37]" style={{ filter: 'drop-shadow(0 0 8px rgba(244, 224, 77, 0.6))' }} />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 rounded-full w-5 h-5 flex items-center justify-center text-xs text-[#0A0A0A]" style={{ background: 'linear-gradient(135deg, #FFE55C 0%, #D4AF37 50%, #B8941F 100%)', fontWeight: 700 }}>
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}