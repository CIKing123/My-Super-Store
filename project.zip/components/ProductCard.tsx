import { Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
}

interface ProductCardProps {
  product: Product;
  onProductClick: (id: number) => void;
}

export function ProductCard({ product, onProductClick }: ProductCardProps) {
  return (
    <div 
      onClick={() => onProductClick(product.id)}
      className="bg-[#0A0A0A] overflow-hidden group cursor-pointer"
    >
      {/* Image Container */}
      <div className="relative aspect-square overflow-hidden bg-white">
        <ImageWithFallback
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <button className="absolute top-4 right-4 transition-colors bg-transparent border-none p-0 cursor-pointer">
          <Heart size={24} strokeWidth={2.5} className="text-[#D4AF37]" style={{ filter: 'drop-shadow(0 0 6px rgba(244, 224, 77, 0.5))' }} />
        </button>
      </div>

      {/* Product Info */}
      <div className="p-6">
        <p className="text-gray-400 mb-2">{product.category}</p>
        <h3 className="text-white mb-4">{product.name}</h3>
        <div className="bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent" style={{ fontWeight: 700 }}>
          ${product.price.toLocaleString()}
        </div>
      </div>
    </div>
  );
}