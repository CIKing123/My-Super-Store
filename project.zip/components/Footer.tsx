import { Instagram, Facebook, Twitter } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#0A0A0A] text-white mt-32">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="tracking-widest mb-6 bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent" style={{ fontWeight: 700 }}>
              LUXE
            </div>
            <p className="text-gray-400">
              Curating excellence in luxury fashion and accessories since 2025.
            </p>
          </div>

          {/* Shop */}
          <div>
            <h4 className="mb-6 bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent">Shop</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">New Arrivals</a></li>
              <li><a href="#" className="text-gray-400 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">Best Sellers</a></li>
              <li><a href="#" className="text-gray-400 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">Collections</a></li>
              <li><a href="#" className="text-gray-400 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">Sale</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="mb-6 bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent">Support</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">Contact Us</a></li>
              <li><a href="#" className="text-gray-400 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">Shipping Info</a></li>
              <li><a href="#" className="text-gray-400 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">Returns</a></li>
              <li><a href="#" className="text-gray-400 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">FAQ</a></li>
            </ul>
          </div>

          {/* Connect */}
          <div>
            <h4 className="mb-6 bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent">Connect</h4>
            <div className="flex gap-4">
              <a href="#" className="text-gray-400 hover:text-[#FFE55C] transition-colors">
                <Instagram size={24} strokeWidth={2.5} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#FFE55C] transition-colors">
                <Facebook size={24} strokeWidth={2.5} />
              </a>
              <a href="#" className="text-gray-400 hover:text-[#FFE55C] transition-colors">
                <Twitter size={24} strokeWidth={2.5} />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 flex items-center justify-between">
          <p className="text-gray-500">© 2025 LUXE. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="text-gray-500 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent transition-colors no-underline">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}