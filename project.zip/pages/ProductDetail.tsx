import { useState } from 'react';
import { Heart, Truck, Shield, RotateCcw, Star, Minus, Plus } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  description?: string;
}

interface ProductDetailProps {
  product: Product;
  onAddToCart: (productId: number, quantity: number) => void;
}

export function ProductDetail({ product, onAddToCart }: ProductDetailProps) {
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState('One Size');

  const sizes = ['Small', 'Medium', 'Large', 'One Size'];

  const handleAddToCart = () => {
    onAddToCart(product.id, quantity);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="grid grid-cols-2 gap-16">
        {/* Product Images */}
        <div>
          <div className="aspect-square bg-white mb-6">
            <ImageWithFallback
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-square bg-white border-2 border-transparent hover:border-[#D4AF37] transition-colors cursor-pointer">
                <ImageWithFallback
                  src={product.image}
                  alt={`${product.name} view ${i}`}
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div>
          <div className="bg-[#0A0A0A] p-12">
            <p className="text-gray-400 mb-4">{product.category}</p>
            <h1 className="text-white mb-6">{product.name}</h1>
            
            {/* Rating */}
            <div className="flex items-center gap-2 mb-8">
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star 
                    key={star} 
                    size={20} 
                    strokeWidth={2.5} 
                    style={{ 
                      fill: 'url(#gold-gradient)',
                      stroke: '#D4AF37',
                      filter: 'drop-shadow(0 0 4px rgba(244, 224, 77, 0.5))'
                    }} 
                  />
                ))}
                <svg width="0" height="0">
                  <defs>
                    <linearGradient id="gold-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#FFE55C" />
                      <stop offset="50%" stopColor="#D4AF37" />
                      <stop offset="100%" stopColor="#B8941F" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>
              <span className="text-gray-400">(127 reviews)</span>
            </div>

            {/* Price */}
            <div className="mb-12 bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent" style={{ fontWeight: 700, fontSize: '2rem' }}>
              ${product.price.toLocaleString()}
            </div>

            {/* Description */}
            <p className="text-gray-400 mb-12 leading-relaxed">
              {product.description || 'An exquisite piece crafted with unparalleled attention to detail. This luxury item represents the pinnacle of design and quality, perfect for those who appreciate the finer things in life.'}
            </p>

            {/* Size Selection */}
            <div className="mb-12">
              <h4 className="text-white mb-4">Select Size</h4>
              <div className="grid grid-cols-4 gap-3">
                {sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`
                      px-4 py-3 transition-all cursor-pointer
                      ${selectedSize === size
                        ? 'text-[#0A0A0A]'
                        : 'bg-transparent text-white hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent'
                      }
                    `}
                    style={selectedSize === size ? { 
                      background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
                      boxShadow: '0 4px 16px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
                      fontWeight: 700,
                      border: 'none'
                    } : { border: '2px solid white' }}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div className="mb-12">
              <h4 className="text-white mb-4">Quantity</h4>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-12 h-12 flex items-center justify-center bg-transparent border-2 border-white text-white hover:border-[#D4AF37] hover:text-[#D4AF37] transition-colors cursor-pointer"
                >
                  <Minus size={20} strokeWidth={2.5} />
                </button>
                <span className="text-white w-12 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-12 h-12 flex items-center justify-center bg-transparent border-2 border-white text-white hover:border-[#D4AF37] hover:text-[#D4AF37] transition-colors cursor-pointer"
                >
                  <Plus size={20} strokeWidth={2.5} />
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-4 mb-12">
              <button 
                onClick={handleAddToCart}
                className="flex-1 py-5 cursor-pointer border-none transition-all text-[#0A0A0A]"
                style={{ 
                  background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
                  boxShadow: '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
                  fontWeight: 700
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.boxShadow = '0 12px 32px rgba(212, 175, 55, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                Add to Cart
              </button>
              <button className="w-16 h-16 flex items-center justify-center bg-transparent border-2 border-white text-white hover:border-[#D4AF37] hover:text-[#D4AF37] transition-colors cursor-pointer">
                <Heart size={24} strokeWidth={2.5} />
              </button>
            </div>

            {/* Buy Now */}
            <button 
              className="w-full bg-transparent py-5 cursor-pointer transition-all mb-12 text-[#0A0A0A]"
              style={{ 
                border: '2px solid transparent',
                borderImage: 'linear-gradient(135deg, #FFE55C, #D4AF37, #B8941F) 1',
                background: 'transparent',
                fontWeight: 700
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)';
                e.currentTarget.style.borderImage = 'none';
                e.currentTarget.style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.borderImage = 'linear-gradient(135deg, #FFE55C, #D4AF37, #B8941F) 1';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <span className="bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent">Buy Now</span>
            </button>

            {/* Features */}
            <div className="space-y-6">
              <div className="flex items-center gap-4 text-gray-400">
                <Truck size={24} strokeWidth={2.5} style={{ color: '#D4AF37', filter: 'drop-shadow(0 0 6px rgba(244, 224, 77, 0.5))' }} />
                <span>Free shipping worldwide</span>
              </div>
              <div className="flex items-center gap-4 text-gray-400">
                <Shield size={24} strokeWidth={2.5} style={{ color: '#D4AF37', filter: 'drop-shadow(0 0 6px rgba(244, 224, 77, 0.5))' }} />
                <span>Authenticity guaranteed</span>
              </div>
              <div className="flex items-center gap-4 text-gray-400">
                <RotateCcw size={24} strokeWidth={2.5} style={{ color: '#D4AF37', filter: 'drop-shadow(0 0 6px rgba(244, 224, 77, 0.5))' }} />
                <span>30-day return policy</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}