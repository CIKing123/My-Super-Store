import { ArrowRight, Star, Shield, Truck } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
}

interface HomeProps {
  products: Product[];
  onNavigate: (page: string, productId?: number) => void;
}

export function Home({ products, onNavigate }: HomeProps) {
  const featuredProducts = products.slice(0, 4);

  return (
    <div>
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-24">
        <div className="max-w-4xl">
          <h1 className="text-[#0A0A0A] mb-8">
            Redefine Luxury.<br />
            Embrace Excellence.
          </h1>
          <p className="text-gray-600 mb-12 max-w-2xl">
            Discover our curated collection of exceptional pieces that transcend time and trends. Each item is meticulously selected to elevate your lifestyle.
          </p>
          <button 
            onClick={() => onNavigate('shop')}
            className="cursor-pointer border-none transition-all inline-flex items-center gap-3 px-12 py-5 text-[#0A0A0A]"
            style={{ 
              background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
              boxShadow: '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
              fontWeight: 700
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.boxShadow = '0 12px 32px rgba(212, 175, 55, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            Explore Collection
            <ArrowRight size={20} strokeWidth={3} />
          </button>
        </div>
      </section>

      {/* Features */}
      <section className="bg-[#0A0A0A] py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-3 gap-12">
            <div className="text-center">
              <div 
                className="inline-flex items-center justify-center w-16 h-16 mb-6"
                style={{ 
                  background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
                  boxShadow: '0 4px 16px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)'
                }}
              >
                <Star size={32} strokeWidth={2.5} className="text-[#0A0A0A]" />
              </div>
              <h4 className="text-white mb-3">Premium Quality</h4>
              <p className="text-gray-400">Only the finest materials and craftsmanship</p>
            </div>
            <div className="text-center">
              <div 
                className="inline-flex items-center justify-center w-16 h-16 mb-6"
                style={{ 
                  background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
                  boxShadow: '0 4px 16px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)'
                }}
              >
                <Shield size={32} strokeWidth={2.5} className="text-[#0A0A0A]" />
              </div>
              <h4 className="text-white mb-3">Authenticity Guaranteed</h4>
              <p className="text-gray-400">Every piece is verified and certified</p>
            </div>
            <div className="text-center">
              <div 
                className="inline-flex items-center justify-center w-16 h-16 mb-6"
                style={{ 
                  background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
                  boxShadow: '0 4px 16px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)'
                }}
              >
                <Truck size={32} strokeWidth={2.5} className="text-[#0A0A0A]" />
              </div>
              <h4 className="text-white mb-3">White Glove Delivery</h4>
              <p className="text-gray-400">Complimentary luxury shipping worldwide</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-6 py-24">
        <div className="flex items-center justify-between mb-12">
          <h2 className="text-[#0A0A0A]">Featured Collection</h2>
          <button 
            onClick={() => onNavigate('shop')}
            className="inline-flex items-center gap-2 bg-transparent border-none cursor-pointer transition-all bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent"
            style={{ fontWeight: 700 }}
          >
            View All
            <ArrowRight size={20} strokeWidth={3} className="text-[#D4AF37]" />
          </button>
        </div>
        
        <div className="grid grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard 
              key={product.id} 
              product={product}
              onProductClick={(id) => onNavigate('product', id)}
            />
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-[#0A0A0A] py-24">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h2 className="text-white mb-6">Join the Elite</h2>
          <p className="text-gray-400 mb-12 max-w-2xl mx-auto">
            Subscribe to receive exclusive access to limited editions, private sales, and curated recommendations.
          </p>
          <div className="flex gap-4 max-w-xl mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 bg-white text-[#0A0A0A] px-6 py-4 border-none outline-none"
            />
            <button className="px-12 cursor-pointer border-none transition-all text-[#0A0A0A]"
              style={{ 
                background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
                boxShadow: '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
                fontWeight: 700
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 12px 32px rgba(212, 175, 55, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
                e.currentTarget.style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
                e.currentTarget.style.transform = 'translateY(0)';
              }}
            >
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}