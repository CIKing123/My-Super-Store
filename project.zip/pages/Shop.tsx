import { useState } from 'react';
import { ChevronDown, SlidersHorizontal } from 'lucide-react';
import { ProductCard } from '../components/ProductCard';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
}

interface ShopProps {
  products: Product[];
  onNavigate: (page: string, productId?: number) => void;
}

export function Shop({ products, onNavigate }: ShopProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('featured');

  const categories = ['All', 'Watches', 'Bags', 'Accessories', 'Jewelry', 'Footwear'];

  const filteredProducts = selectedCategory === 'All' 
    ? products 
    : products.filter(p => p.category === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      {/* Page Header */}
      <div className="mb-12">
        <h1 className="text-[#0A0A0A] mb-4">Luxury Collection</h1>
        <p className="text-gray-600">
          {filteredProducts.length} exceptional pieces
        </p>
      </div>

      {/* Filters and Sort */}
      <div className="flex items-center justify-between mb-12 pb-6" style={{ borderBottom: '2px solid transparent', borderImage: 'linear-gradient(90deg, #FFE55C, #D4AF37, #B8941F) 1' }}>
        {/* Category Filters */}
        <div className="flex gap-6">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`
                px-6 py-3 transition-all cursor-pointer border-none
                ${selectedCategory === category
                  ? 'text-[#0A0A0A]'
                  : 'bg-transparent text-[#0A0A0A] hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent'
                }
              `}
              style={selectedCategory === category ? { 
                background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
                boxShadow: '0 4px 16px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
                fontWeight: 700
              } : {}}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Sort */}
        <div className="flex items-center gap-4">
          <button className="flex items-center gap-2 text-[#0A0A0A] transition-colors bg-transparent border-none cursor-pointer hover:bg-gradient-to-r hover:from-[#FFE55C] hover:via-[#D4AF37] hover:to-[#B8941F] hover:bg-clip-text hover:text-transparent">
            <SlidersHorizontal size={20} strokeWidth={2.5} />
            Filters
          </button>
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="appearance-none bg-[#0A0A0A] text-white px-6 py-3 pr-10 border-none cursor-pointer outline-none"
            >
              <option value="featured">Featured</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="newest">Newest</option>
            </select>
            <ChevronDown 
              size={20} 
              className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" 
              strokeWidth={2.5}
              style={{ filter: 'drop-shadow(0 0 6px rgba(244, 224, 77, 0.5))', color: '#D4AF37' }}
            />
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-4 gap-6">
        {filteredProducts.map((product) => (
          <ProductCard 
            key={product.id} 
            product={product}
            onProductClick={(id) => onNavigate('product', id)}
          />
        ))}
      </div>

      {/* Load More */}
      <div className="text-center mt-16">
        <button className="bg-[#0A0A0A] hover:bg-[#1A1A1A] text-white px-16 py-4 cursor-pointer border-none transition-colors">
          Load More
        </button>
      </div>
    </div>
  );
}