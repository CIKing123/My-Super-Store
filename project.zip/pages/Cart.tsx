import { Minus, Plus, X } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

interface CartItem {
  id: number;
  name: string;
  price: number;
  image: string;
  quantity: number;
  category: string;
}

interface CartProps {
  cartItems: CartItem[];
  onUpdateQuantity: (id: number, quantity: number) => void;
  onRemoveItem: (id: number) => void;
  onNavigate: (page: string) => void;
}

export function Cart({ cartItems, onUpdateQuantity, onRemoveItem, onNavigate }: CartProps) {
  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shipping = subtotal > 500 ? 0 : 50;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <h1 className="text-[#0A0A0A] mb-12">Shopping Cart</h1>

      {cartItems.length === 0 ? (
        <div className="bg-[#0A0A0A] p-24 text-center">
          <h3 className="text-white mb-6">Your cart is empty</h3>
          <p className="text-gray-400 mb-12">Discover our exceptional collection</p>
          <button 
            onClick={() => onNavigate('shop')}
            className="px-12 py-4 cursor-pointer border-none transition-all text-[#0A0A0A]"
            style={{ 
              background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
              boxShadow: '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
              fontWeight: 700
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.boxShadow = '0 12px 32px rgba(212, 175, 55, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
              e.currentTarget.style.transform = 'translateY(0)';
            }}
          >
            Continue Shopping
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-12">
          {/* Cart Items */}
          <div className="col-span-2 space-y-6">
            {cartItems.map((item) => (
              <div key={item.id} className="bg-[#0A0A0A] p-6">
                <div className="flex gap-6">
                  {/* Image */}
                  <div className="w-32 h-32 bg-white flex-shrink-0">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Details */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <p className="text-gray-400 mb-2">{item.category}</p>
                        <h4 className="text-white mb-2">{item.name}</h4>
                        <div className="bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent" style={{ fontWeight: 700 }}>
                          ${item.price.toLocaleString()}
                        </div>
                      </div>
                      <button
                        onClick={() => onRemoveItem(item.id)}
                        className="text-gray-400 hover:text-[#D4AF37] transition-colors bg-transparent border-none cursor-pointer p-0"
                      >
                        <X size={24} strokeWidth={2.5} />
                      </button>
                    </div>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-4">
                      <button
                        onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                        className="w-10 h-10 flex items-center justify-center bg-transparent border-2 border-white text-white hover:border-[#D4AF37] hover:text-[#D4AF37] transition-colors cursor-pointer"
                      >
                        <Minus size={16} strokeWidth={2.5} />
                      </button>
                      <span className="text-white w-8 text-center">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                        className="w-10 h-10 flex items-center justify-center bg-transparent border-2 border-white text-white hover:border-[#D4AF37] hover:text-[#D4AF37] transition-colors cursor-pointer"
                      >
                        <Plus size={16} strokeWidth={2.5} />
                      </button>
                      <div className="ml-auto bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent" style={{ fontWeight: 700 }}>
                        ${(item.price * item.quantity).toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-[#0A0A0A] p-8 sticky top-24">
              <h3 className="text-white mb-8">Order Summary</h3>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center justify-between text-gray-400">
                  <span>Subtotal</span>
                  <span>${subtotal.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between text-gray-400">
                  <span>Shipping</span>
                  <span>{shipping === 0 ? 'Free' : `$${shipping}`}</span>
                </div>
                <div className="flex items-center justify-between text-gray-400">
                  <span>Tax</span>
                  <span>${tax.toFixed(2)}</span>
                </div>
                
                <div className="border-t-2 border-[#D4AF37] pt-4 mt-6" style={{ borderImage: 'linear-gradient(90deg, #FFE55C, #D4AF37, #B8941F) 1' }}>
                  <div className="flex items-center justify-between text-white">
                    <span>Total</span>
                    <div className="bg-gradient-to-r from-[#FFE55C] via-[#D4AF37] to-[#B8941F] bg-clip-text text-transparent" style={{ fontWeight: 700, fontSize: '1.5rem' }}>
                      ${total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                  </div>
                </div>
              </div>

              <button 
                className="w-full py-5 mb-4 cursor-pointer border-none transition-all text-[#0A0A0A]"
                style={{ 
                  background: 'linear-gradient(135deg, #FFE55C 0%, #F4D03F 25%, #D4AF37 50%, #C5A028 75%, #B8941F 100%)',
                  boxShadow: '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)',
                  fontWeight: 700
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.boxShadow = '0 12px 32px rgba(212, 175, 55, 0.6), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
                  e.currentTarget.style.transform = 'translateY(-2px)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)';
                  e.currentTarget.style.transform = 'translateY(0)';
                }}
              >
                Proceed to Checkout
              </button>

              <button 
                onClick={() => onNavigate('shop')}
                className="w-full bg-transparent border-2 border-white text-white hover:border-[#D4AF37] hover:text-[#D4AF37] py-4 cursor-pointer transition-all"
              >
                Continue Shopping
              </button>

              {/* Free Shipping Message */}
              {subtotal < 500 && (
                <div className="mt-6 p-4 border-2 border-[#D4AF37]">
                  <p className="text-gray-400 text-center">
                    Add ${(500 - subtotal).toLocaleString()} more for free shipping
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}