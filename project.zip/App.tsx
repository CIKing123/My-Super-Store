import { useState } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Shop } from './pages/Shop';
import { ProductDetail } from './pages/ProductDetail';
import { Cart } from './pages/Cart';

interface Product {
  id: number;
  name: string;
  price: number;
  image: string;
  category: string;
  description?: string;
}

interface CartItem extends Product {
  quantity: number;
}

const products: Product[] = [
  {
    id: 1,
    name: 'Chronograph Elite',
    price: 12500,
    image: 'https://images.unsplash.com/photo-1670177257750-9b47927f68eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB3YXRjaHxlbnwxfHx8fDE3NjU1NjUxMzB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Watches',
    description: 'Swiss-made precision timepiece featuring a chronograph movement, sapphire crystal, and 18k gold accents. Water-resistant to 100m.',
  },
  {
    id: 2,
    name: 'Heritage Tote',
    price: 8900,
    image: 'https://images.unsplash.com/photo-1601924928357-22d3b3abfcfb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMGhhbmRiYWd8ZW58MXx8fHwxNzY1NTk0ODkzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Bags',
    description: 'Handcrafted Italian leather tote with gold-plated hardware. Features multiple compartments and signature embossed detailing.',
  },
  {
    id: 3,
    name: 'Aviator Collection',
    price: 2400,
    image: 'https://images.unsplash.com/photo-1589642380614-4a8c2147b857?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBzdW5nbGFzc2VzfGVufDF8fHx8MTc2NTYxODEzOXww&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Accessories',
    description: 'Polarized sunglasses with titanium frames and gradient lenses. Includes leather case and microfiber cloth.',
  },
  {
    id: 4,
    name: 'Studio Pro Elite',
    price: 5600,
    image: 'https://images.unsplash.com/photo-1723961617032-ef69c454cb31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwaGVhZHBob25lc3xlbnwxfHx8fDE3NjU2MjQzNTV8MA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Accessories',
    description: 'Premium wireless headphones with active noise cancellation, 40-hour battery life, and audiophile-grade sound quality.',
  },
  {
    id: 5,
    name: 'Noir Essence',
    price: 3800,
    image: 'https://images.unsplash.com/photo-1615160460367-dcccd27e11ad?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZXJmdW1lfGVufDF8fHx8MTc2NTU5MzU1N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Accessories',
    description: 'Signature fragrance featuring notes of oud, amber, and sandalwood. 100ml eau de parfum in hand-blown crystal bottle.',
  },
  {
    id: 6,
    name: 'Oxford Prestige',
    price: 4200,
    image: 'https://images.unsplash.com/photo-1625622176700-e55445383b85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ25lciUyMHNob2VzfGVufDF8fHx8MTc2NTYxODEzOHww&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Footwear',
    description: 'Handcrafted Italian leather Oxford shoes with Goodyear welt construction and leather soles. Made-to-order sizing available.',
  },
  {
    id: 7,
    name: 'Diamond Eternity',
    price: 28500,
    image: 'https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBqZXdlbHJ5fGVufDF8fHx8MTc2NTYxODEzOHww&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Jewelry',
    description: 'Platinum ring set with conflict-free diamonds totaling 2.5 carats. Certified by independent gemological institute.',
  },
  {
    id: 8,
    name: 'Executive Billfold',
    price: 1850,
    image: 'https://images.unsplash.com/photo-1693657606674-8d7fd5a0dd6a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcmVtaXVtJTIwbGVhdGhlciUyMHdhbGxldHxlbnwxfHx8fDE3NjU2MzIxMTN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    category: 'Accessories',
    description: 'Full-grain leather wallet with RFID protection. Features 8 card slots, bill compartment, and signature gold accents.',
  },
];

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleNavigate = (page: string, productId?: number) => {
    setCurrentPage(page);
    if (productId) {
      setSelectedProductId(productId);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToCart = (productId: number, quantity: number) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === productId);
      if (existingItem) {
        return prevItems.map(item =>
          item.id === productId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        return [...prevItems, { ...product, quantity }];
      }
    });

    // Show feedback
    alert('Added to cart!');
  };

  const handleUpdateQuantity = (productId: number, quantity: number) => {
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
  };

  const selectedProduct = products.find(p => p.id === selectedProductId);

  return (
    <div className="min-h-screen bg-white">
      <Header 
        currentPage={currentPage} 
        onNavigate={handleNavigate}
        cartItemCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
      />
      
      {currentPage === 'home' && (
        <Home products={products} onNavigate={handleNavigate} />
      )}
      
      {currentPage === 'shop' && (
        <Shop products={products} onNavigate={handleNavigate} />
      )}
      
      {currentPage === 'product' && selectedProduct && (
        <ProductDetail 
          product={selectedProduct}
          onAddToCart={handleAddToCart}
        />
      )}
      
      {currentPage === 'cart' && (
        <Cart 
          cartItems={cartItems}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
          onNavigate={handleNavigate}
        />
      )}
      
      <Footer />
    </div>
  );
}
